#include "../include/memelem_stornode.h"
#include <cstring>
#include <unistd.h>

memelem_stornode::memelem_stornode(int keylen, int vallen)
{
    this->var_keylen=keylen;
    this->var_vallen=vallen;
    this->var_nodemap_counts=0;
    pthread_rwlock_init(&(this->rwlock_noderw), NULL);
    this->atmvar_requestcounts.store(0, std::memory_order_relaxed);
}

memelem_stornode::memelem_stornode(const memelem_stornode& other)
{

    var_nodemap_counts=0;
    this->var_keylen=other.var_keylen;
    this->var_vallen=other.var_vallen;
    pthread_rwlock_init(&(this->rwlock_noderw), NULL);
    char tmp_key[var_keylen];
    char tmp_val[var_vallen];
    for (auto it = other.map_node.begin(); it != other.map_node.end(); ++it)
    {
        it->first.implic(tmp_key);
        it->second->implic(tmp_val);
        this->node_reinst(tmp_key, tmp_val);
    }
}

memelem_stornode::~memelem_stornode()
{
    pthread_rwlock_wrlock(&(this->rwlock_noderw));
    for (auto it = map_node.begin(); it != map_node.end();)
    {
        if (it->second)
        {
            delete it->second;
        }
        auto nextIt = std::next(it);
        map_node.erase(it);
        it = nextIt;
    }
    pthread_rwlock_unlock(&(this->rwlock_noderw));
    pthread_rwlock_destroy(&(this->rwlock_noderw));
}

int memelem_stornode::node_clear()
{
    pthread_rwlock_wrlock(&(this->rwlock_noderw));
    for (auto it = map_node.begin(); it != map_node.end();)
    {
        if (it->second)
        {
            delete it->second;
        }
        auto nextIt = std::next(it);
        map_node.erase(it);
        it = nextIt;
        this->var_nodemap_counts--;
    }
    pthread_rwlock_unlock(&(this->rwlock_noderw));
    return 1;
}

int memelem_stornode::node_insert(void* srckey, void* srcval)
{

    if(this->node_isexist(srckey)==1)return 0;

    pthread_rwlock_wrlock(&(this->rwlock_noderw));
    this->var_nodemap_counts++;
    memelem new_keyelem(srckey, this->var_keylen);
    memelem* new_valelem = new memelem(srcval, this->var_vallen);

    this->map_node[new_keyelem]=new_valelem;
    pthread_rwlock_unlock(&(this->rwlock_noderw));

    return 1;
}

int memelem_stornode::node_reinst(void* srckey, void* srcval)
{
    pthread_rwlock_wrlock(&(this->rwlock_noderw));
    int rst=0;
    memelem new_keyelem(srckey, this->var_keylen);
    //memelem* new_valelem = new memelem(srcval, this->var_vallen);

    auto it = map_node.find(new_keyelem);
    if(it==map_node.end())
    {
        this->var_nodemap_counts++;

        memelem* new_valelem = new memelem(srcval, this->var_vallen);
        map_node[new_keyelem]=new_valelem;
        rst=1;
    }
    else
    {
        rst=
        it->second->revice(srcval);
    }
    pthread_rwlock_unlock(&(this->rwlock_noderw));
    return rst;
}

int memelem_stornode::node_isexist(void* dstkey)
{
    this->atmvar_requestcounts.fetch_add(1, std::memory_order_relaxed);
    int rst=0;
    pthread_rwlock_rdlock(&(this->rwlock_noderw));

    memelem target_keyelem(dstkey, this->var_keylen);
    auto it = map_node.find(target_keyelem);

    if (it != map_node.end())rst=1;
    else rst=-1;
    pthread_rwlock_unlock(&(this->rwlock_noderw));
    return rst;
}

int memelem_stornode::node_implic(void* dstkey, void* dstbuf)
{

    this->atmvar_requestcounts.fetch_add(1, std::memory_order_relaxed);
    int rst=0;
    pthread_rwlock_rdlock(&(this->rwlock_noderw));

    memelem target_keyelem(dstkey, this->var_keylen);
    auto it = map_node.find(target_keyelem);
    if (it == map_node.end())rst=-1;
    else
    {
        rst=1;
        it->second->implic(dstbuf);
    }
    pthread_rwlock_unlock(&(this->rwlock_noderw));

    return rst;
}

int memelem_stornode::node_delete(void* dstkey)
{
    pthread_rwlock_wrlock(&(this->rwlock_noderw));
    int rst=0;
    memelem target_keyelem(dstkey, this->var_keylen);
    auto it = map_node.find(target_keyelem);

    if (it == map_node.end())rst=-1;
    else
    {
        this->var_nodemap_counts--;
        rst=1;
        if(it->second)
            delete it->second;
        this->map_node.erase(it);
    }

    pthread_rwlock_unlock(&(this->rwlock_noderw));
    return rst;
}

int memelem_stornode::node_nodecmp(const memelem_stornode& other)
{
    if(other.var_nodemap_counts!=this->var_nodemap_counts)return -1;
    if(other.var_keylen!=this->var_keylen || other.var_vallen!=this->var_vallen)return -1;
    char tmp_key[this->var_keylen];
    char tmp_val1[this->var_vallen];
    char tmp_val2[this->var_vallen];
    for (auto it = other.map_node.begin(); it != other.map_node.end(); ++it)
    {
        it->first.implic(tmp_key);
        it->second->implic(tmp_val1);

        if(this->node_implic(tmp_key, tmp_val2) != 1)return -1;
        if(memcmp(tmp_val2, tmp_val1, this->var_vallen)!=0)return -1;
        //this->atmvar_requestcounts.fetch_add(1, std::memory_order_relaxed);

    }
    return 1;
}

int memelem_stornode::node_getcounts()
{
    this->atmvar_requestcounts.fetch_add(1, std::memory_order_relaxed);

    pthread_rwlock_rdlock(&(this->rwlock_noderw));
    int result=this->var_nodemap_counts;
    pthread_rwlock_unlock(&(this->rwlock_noderw));
    return result;
}

unsigned long memelem_stornode::node_getrequestcounts()
{
    return this->atmvar_requestcounts.load(std::memory_order_relaxed);
}



































