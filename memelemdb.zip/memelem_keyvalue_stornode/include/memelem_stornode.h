#ifndef MEMELEM_STORNODE_H
#define MEMELEM_STORNODE_H
#include "../../memelem_keyvaluedb/include/memelem_define.h"
#include <atomic>
#include <pthread.h>
#include <map>

class memelem_stornode
{
public:
    std::map<memelem, memelem*> map_node;

    pthread_rwlock_t rwlock_noderw;

    int var_keylen;
    int var_vallen;
    int var_nodemap_counts;
    std::atomic<unsigned long> atmvar_requestcounts;
public:
    memelem_stornode(int keylen, int vallen);
    memelem_stornode(const memelem_stornode& other);
    ~memelem_stornode();

    int node_insert(void* srckey, void* srcval);
    int node_implic(void* dstkey, void* dstbuf);
    int node_delete(void* dstkey);
    int node_isexist(void* dstkey);
    int node_reinst(void* srckey, void* srcval);
    int node_clear();
    int node_getcounts();

    unsigned long node_getrequestcounts();


    int node_nodecmp(const memelem_stornode& other);
};

#endif
