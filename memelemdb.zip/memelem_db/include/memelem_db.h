#ifndef MEMELEM_DB_H
#define MEMELEM_DB_H
#include "../../memelem_keyvalue_stornode/include/memelem_stornode.h"
#include <atomic>
#include <mutex>
#include "../../progschj_threadpool/include/ThreadPool.h"
#include <cstring>
#include <string>
class memelem_db
{
public:
    ThreadPool* TP;
public:
    memelem_db(int keylen, int vallen);
    ~memelem_db();
    std::atomic<void*> stornode_main;
    std::mutex mtx_increase_space;
    std::atomic<void*> stornode_standby_increase;
    int db_reinst(void* key, void* val);
    int db_delete(void* key);
    int db_isexist(void* key);
    int db_implic(void* key, void* dstbf);
    int db_getcounts();
private:
    int db_precheck();
    int db_replace();
    int db_unreplace();
    static void db_node_clean(void* stornode);

public:
    std::atomic<void*> stornode_standby_empty;
    std::mutex mtx_empty_space;
    int db_e_insert(void* key, void* val);
    int db_e_precheck();
    int db_e_replace();
public:

    int var_keylen;
    int var_vallen;
    std::atomic<unsigned long> count_db_requset_successed;
    std::atomic<unsigned long> count_db_requset_failed;
    std::atomic<unsigned long> count_of_newnode_created;
    std::atomic<unsigned long> count_of_oldnode_deleted;

public:
//dynamic performance config
    int nodeclean_chiletime;
    int db_setchilltime(int cts);
    int db_maxelemcounts;
    int db_setmaxcounts(int mxc);
    std::string ouput_debuginfo_tojson();
};

#endif
