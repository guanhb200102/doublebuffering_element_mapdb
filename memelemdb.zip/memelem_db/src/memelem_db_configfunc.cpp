
#include "../include/memelem_db.h"

int memelem_db::db_setchilltime(int cts)
{
    this->nodeclean_chiletime=cts;
    return cts;
}

int memelem_db::db_setmaxcounts(int mxc)
{
    this->db_maxelemcounts=mxc;
    return mxc;
}

std::string memelem_db::ouput_debuginfo_tojson()
{
    json j;
    j["elem_counts"]=this->db_getcounts();
    j["request_failed"]=this->count_db_requset_failed.load(std::memory_order_relaxed);
    j["request_successed"]=this->count_db_requset_successed.load(std::memory_order_relaxed);
    j["stornode_created"]=this->count_of_newnode_created.load(std::memory_order_relaxed);
    j["stornode_deleted"]=this->count_of_oldnode_deleted.load(std::memory_order_relaxed);
    return j.dump(4);
}
