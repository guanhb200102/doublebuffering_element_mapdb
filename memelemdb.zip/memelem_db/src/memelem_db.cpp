#include "../include/memelem_db.h"
#include <unistd.h>
#include <iostream>
#include <nlohmann/json.hpp>
memelem_db::memelem_db(int keylen, int vallen)
{
    this->stornode_main.store(NULL, std::memory_order_relaxed);
    this->stornode_standby_empty.store(NULL, std::memory_order_relaxed);
    this->stornode_standby_increase.store(NULL, std::memory_order_relaxed);

    memelem_stornode* newnode= new memelem_stornode(keylen, vallen);
    this->count_of_newnode_created=0;
    this->count_of_oldnode_deleted=0;

    this->var_keylen=keylen;
    this->var_vallen=vallen;
    this->stornode_main.store(newnode, std::memory_order_relaxed);
    this->count_db_requset_failed.store(0, std::memory_order_relaxed);
    this->count_db_requset_successed.store(0, std::memory_order_relaxed);
    this->TP=new ThreadPool(1);
    this->nodeclean_chiletime=1000000;
    this->db_maxelemcounts=512;
}

memelem_db::~memelem_db()
{
    memelem_stornode* current_mainnode=(memelem_stornode*)this->stornode_main.load(std::memory_order_relaxed);
    delete TP;
}

int memelem_db::db_precheck()
{
    memelem_stornode* current_mainnode=(memelem_stornode*)this->stornode_main.load(std::memory_order_relaxed);
    memelem_stornode* newincreaseone=new memelem_stornode(*current_mainnode);
    this->count_of_newnode_created.fetch_add(1, std::memory_order_relaxed);
    this->stornode_standby_increase.store(newincreaseone, std::memory_order_relaxed);
    return 1;
}

int memelem_db::db_replace()
{

    memelem_stornode* oldone=(memelem_stornode*)this->stornode_main.load(std::memory_order_relaxed);
    memelem_stornode* newone=(memelem_stornode*)this->stornode_standby_increase.load(std::memory_order_relaxed);
    this->stornode_main.store(newone, std::memory_order_relaxed);
    this->stornode_standby_increase.store(NULL, std::memory_order_relaxed);
    this->count_of_oldnode_deleted.fetch_add(1, std::memory_order_relaxed);
    this->TP->enqueue(this->db_node_clean, oldone);

    return 1;
}

int memelem_db::db_unreplace()
{
    memelem_stornode* newone=(memelem_stornode*)this->stornode_standby_increase.load(std::memory_order_relaxed);
    delete newone;
    this->stornode_standby_increase.store(NULL, std::memory_order_relaxed);
    this->count_of_oldnode_deleted.fetch_add(1, std::memory_order_relaxed);
    return 1;
}

int memelem_db::db_reinst(void* key, void* val)
{
    if( this->db_getcounts()>= this->db_maxelemcounts)return -1;

    this->mtx_increase_space.lock();
    this->db_precheck();
    memelem_stornode* newone=(memelem_stornode*)this->stornode_standby_increase.load(std::memory_order_relaxed);
    int result=
        newone->node_reinst(key, val);

    if(result==1)
    {
        this->db_replace();
    }
    else
    {
        this->db_unreplace();
    }
    this->mtx_increase_space.unlock();
    return result;
}

int memelem_db::db_delete(void* key)
{
    if(this->db_isexist(key)!=1)return -1;

    this->mtx_increase_space.lock();
    this->db_precheck();
    memelem_stornode* newone=(memelem_stornode*)this->stornode_standby_increase.load(std::memory_order_relaxed);
    int result=newone->node_delete(key);
    if(result==1)
    {
        this->db_replace();
    }
    else
    {
        this->db_unreplace();
    }
    this->mtx_increase_space.unlock();
    return result;
}

int memelem_db::db_isexist(void* key)
{
    memelem_stornode* mainone=(memelem_stornode*)this->stornode_main.load(std::memory_order_relaxed);
    int result = mainone->node_isexist(key);
    if(result==1)this->count_db_requset_successed.fetch_add(1, std::memory_order_relaxed);
    else this->count_db_requset_failed.fetch_add(1, std::memory_order_relaxed);
    return result;
}

int memelem_db::db_implic(void* key, void* dstbf)
{
    memelem_stornode* mainone=(memelem_stornode*)this->stornode_main.load(std::memory_order_relaxed);
    int result = mainone->node_implic(key, dstbf);
    if(result==1)this->count_db_requset_successed.fetch_add(1, std::memory_order_relaxed);
    else this->count_db_requset_failed.fetch_add(1, std::memory_order_relaxed);
    return result;
}

int memelem_db::db_getcounts()
{
    memelem_stornode* mainone=(memelem_stornode*)this->stornode_main.load(std::memory_order_relaxed);
    int result = mainone->node_getcounts();
    return result;
}


int memelem_db::db_e_insert(void* key, void* val)
{
    memelem_stornode* newone=(memelem_stornode*)this->stornode_standby_empty.load(std::memory_order_relaxed);
    if(newone->node_getcounts()>=this->db_maxelemcounts)return -1;
    newone->node_reinst(key,val);
    return 1;
}

int memelem_db::db_e_precheck()
{
    this->mtx_empty_space.lock();
    memelem_stornode* newemptyone=new memelem_stornode(this->var_keylen, this->var_vallen);
    this->count_of_newnode_created.fetch_add(1, std::memory_order_relaxed);
    this->stornode_standby_empty.store(newemptyone, std::memory_order_relaxed);
    return 1;
}

int memelem_db::db_e_replace()
{
    memelem_stornode* oldone=(memelem_stornode*)this->stornode_main.load(std::memory_order_relaxed);
    memelem_stornode* newone=(memelem_stornode*)this->stornode_standby_empty.load(std::memory_order_relaxed);
    this->stornode_main.store(newone, std::memory_order_relaxed);
    this->stornode_standby_empty.store(NULL, std::memory_order_relaxed);
    this->count_of_oldnode_deleted.fetch_add(1, std::memory_order_relaxed);

    this->TP->enqueue(this->db_node_clean, oldone);
    this->mtx_empty_space.unlock();
    return 1;
}
using json = nlohmann::json;

void memelem_db::db_node_clean(void* stornode)
{
    memelem_stornode* targetnode=(memelem_stornode*)stornode;
    int counts=targetnode->node_getrequestcounts();
    sleep(5);
    while(counts!=targetnode->node_getrequestcounts())
    {
        counts=targetnode->node_getrequestcounts();
        sleep(5);
    }
    delete targetnode;
}















