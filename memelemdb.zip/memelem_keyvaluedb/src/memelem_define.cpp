#include "../include/memelem_define.h"
#include <cstring>

memelem::memelem(void* src, int srclen)
{
    this->keybuflen=srclen;
    this->keybuf=NULL;
    this->keybuf=new char[srclen];
    buf=keybuf;
    if(this->keybuf)memcpy(this->keybuf, src, srclen);
}

memelem::~memelem()
{
    if(this->keybuf)delete[] this->keybuf;
}

memelem::memelem(const memelem& other)
{
    this->keybuflen=other.keybuflen;
    if (other.keybuf)
    {
        keybuf = new char[keybuflen];
        std::memcpy(keybuf, other.keybuf, keybuflen);
    }
    else
    {
        keybuf = nullptr;
    }
}

bool memelem::operator<(const memelem& other) const
{
    return std::memcmp(keybuf, other.keybuf, keybuflen)<0;
}

int memelem::revice(void* src)
{
    int rst;
    if(memcmp(src, this->keybuf, this->keybuflen)!=0)
    {
        memcpy(this->keybuf, src, this->keybuflen);
        rst=1;
    }
    else
        rst=-1;

    return rst;
}

memelem& memelem::operator=(const memelem& other)
{
    if (this != &other)
    {
        delete[] keybuf;
        keybuflen = other.keybuflen;
        if (other.keybuf)
        {
            keybuf = new char[keybuflen];
            std::memcpy(keybuf, other.keybuf, keybuflen);
        }
        else
        {
            keybuf = nullptr;
        }
    }
    return *this;
}

int memelem::implic(void* dst) const
{
    memcpy(dst, keybuf, this->keybuflen);
    return keybuflen;
}
