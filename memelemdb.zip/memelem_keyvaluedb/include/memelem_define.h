#ifndef MEMELEM_DEFINE_H
#define MEMELEM_DEFINE_H

class memelem
{
public:
    char* keybuf;
    char* buf;
    int keybuflen;
    memelem(void* src, int srclen);
    memelem(const memelem& other);
    ~memelem();


public:
    bool operator<(const memelem& other) const;
    memelem& operator=(const memelem& other);
    int implic(void* dst) const;
    int revice(void* src);
};



#endif
